//
//  ShowLocationOnMapViewController.swift
//  2017F_MAD3115_FinalExam_Section_II
//
//  Created by moxDroid on 2017-11-02.
//  Copyright © 2017 moxDroid. All rights reserved.
//  Roll No.    : c0702567
//  Name        : jaspreet kaur

import UIKit
import MapKit

class ShowLocationOnMapViewController: UIViewController {

    
    @IBOutlet weak var myMap: MKMapView!
    
   let collageLocation = CLLocation(latitude: 43.773257, longitude: -79.335899)
    let towncentre = CLLocation(latitude:43.775319 , longitude: -79.257868)
    let indiaLocation = CLLocation(latitude:31.619980 , longitude: 74.876485)
     let downtown = CLLocation(latitude:34.040713 , longitude: -118.246769)
    
    
    
    let regionRadius: CLLocationDistance = 1000
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        
    }
    
    func centreMapOnLocation(location: CLLocation) {
        let coodinateRegion = MKCoordinateRegionMakeWithDistance(location.coordinate, regionRadius, regionRadius)
      myMap.setRegion(coodinateRegion, animated: true)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
