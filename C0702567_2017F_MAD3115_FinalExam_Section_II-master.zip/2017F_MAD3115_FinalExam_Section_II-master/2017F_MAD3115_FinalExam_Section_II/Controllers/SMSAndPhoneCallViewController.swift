//
//  SMSAndPhoneCallViewController.swift
//  2017F_MAD3115_FinalExam_Section_II
//
//  Created by MacStudent on 2017-11-02.
//  Copyright © 2017 moxDroid. All rights reserved.
//  Roll No.    : c0702567
//  Name        : jaspreet kaur

import UIKit
import MessageUI

class SMSAndPhoneCallViewController: UIViewController, MFMailComposeViewControllerDelegate {
    
    
   
    
    @IBOutlet weak var lblName: UITextField!
    

    @IBOutlet weak var btnCall: UIButton!
    
    
    @IBOutlet weak var btnSMS: UIButton!
    
    
    @IBOutlet weak var btnSendAnEmail: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    func canSendText() -> Bool{
        return MFMessageComposeViewController.canSendText()
        
    }
    
    
    func composeSMS () -> MFMessageComposeViewController {
        let messageCompose = MFMessageComposeViewController()
        messageCompose.messageComposeDelegate = self as! MFMessageComposeViewControllerDelegate
        messageCompose.recipients = ["416-565-5059"]
        messageCompose.body =  "welcome to the ios programming"
        return messageCompose
        
    }
    
    func messageComposeViewController(controller: MFMessageComposeViewController!, didFinishWithResult result: MessageComposeResult) {
        controller.dismiss(animated: true, completion: nil)
    }

    
    @IBAction func btnCall(_ sender: UIButton) {
    }
    
    
    
    @IBAction func btnSMS(_ sender: UIButton) {
        if(message.canSendText()) {
            let messageCompose = message.composeSMS()
            presentedViewController(messageCompose,dismiss(animated: true, completion: nil))
        }
        else {
            
        }
        
        
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

   
    @IBAction func btnSendAnEmail(_ sender: UIButton) {
        
        let storyBoard = UIStoryboard(name: "MAIN", bundle: nil)
        let vc = storyBoard.instantiateViewController(withIdentifier: "SendEmailViewController") as! SendEmailViewController
        
        present(vc, animated: true, completion: nil)
        
    }
}
